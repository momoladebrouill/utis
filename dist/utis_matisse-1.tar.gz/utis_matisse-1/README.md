
# UTIS

Un pseudo module pour gérer les vecteurs et les positions et les angles

### antsfight
Play with ants to learn the basics of OOP !
### Fractions
Tired of floats ? use Fractions insted !
### html
Do you need to do some quick HTML writting ? use html to simplify your typing !
### node, noeyuds
You always need nodes for training real quickly
### vec
You have to know where you're from to know where you should go
### years
un dict des prénoms les plus populaires chaques années depuis  1900  
used in noeyuds.py
